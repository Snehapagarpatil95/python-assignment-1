# Python Assignment 1 - Basic Python Concepts

This repository contains solutions for the following tasks:

## Task 1: Basic Mathematical Operations
- Takes two numbers as input.
- Performs addition, subtraction, multiplication, and division.
- Displays the result of each operation.

## Task 2: Personalized Greeting
- Takes user's first and last name.
- Combines them into a full name.
- Prints a personalized greeting message.

## Files
- `task1_math_operations.py`
- `task2_greeting.py`

## How to Run
Use any Python IDE or terminal:

```bash
python task1_math_operations.py
python task2_greeting.py
```

Ensure Python 3 is installed.